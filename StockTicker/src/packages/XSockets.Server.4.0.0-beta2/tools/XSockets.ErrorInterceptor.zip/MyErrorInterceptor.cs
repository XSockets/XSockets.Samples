using XSockets.Core.Common.Interceptor;
using XSockets.Core.Common.Socket.Exceptions;

namespace $rootnamespace$
{
    public class $safeitemrootname$ : IErrorInterceptor
    {
        public void OnError(IXSocketException exception)
        {
            
        }
    }
}
