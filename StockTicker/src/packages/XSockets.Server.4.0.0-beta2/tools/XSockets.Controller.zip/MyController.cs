using XSockets.Core.XSocket;
using XSockets.Core.XSocket.Helpers;
using XSockets.Core.Common.Socket.Event.Interface;

namespace $rootnamespace$
{
    public class $safeitemrootname$ : XSocketController
    {
        //Implement/Override your custom actionmethods, events etc in this real-time MVC controller
    }  
}
